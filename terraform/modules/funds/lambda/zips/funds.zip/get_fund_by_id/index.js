import { GetCommand } from "@aws-sdk/lib-dynamodb";
import { db } from "../shared/db.js";

export const handler = async (event) => {
  const { id } = event.pathParameters;

  const result = await db.send(
    new GetCommand({
      TableName: process.env.TABLE_NAME || "dev-funds",
      Key: { id },
    }),
  );

  if (!result.Item) {
    return {
      statusCode: 404,
      body: JSON.stringify({ message: "Fondo no encontrado" }),
    };
  }

  return {
    statusCode: 200,
    body: JSON.stringify(result.Item),
  };
};
