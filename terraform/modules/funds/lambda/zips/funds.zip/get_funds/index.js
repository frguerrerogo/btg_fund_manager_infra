import { ScanCommand } from "@aws-sdk/lib-dynamodb";
import { db } from "../shared/db.js";

export const handler = async () => {
  const result = await db.send(
    new ScanCommand({
      TableName: process.env.TABLE_NAME || "dev-funds",
    }),
  );

  return {
    statusCode: 200,
    body: JSON.stringify(result.Items),
  };
};
